package com.bookly.backendcf.auth.presentation.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record RegisterCustomerRequest(
        @NotBlank(message = "El correo es obligatorio")
        @Email(message = "El correo no tiene un formato válido")
        @Size(max = 320, message = "El correo no puede superar 320 caracteres")
        String email,

        @NotBlank(message = "La contraseña es obligatoria")
        @Size(min = 8, max = 64, message = "La contraseña debe tener entre 8 y 64 caracteres")
        @Pattern(
                regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z\\d]).+$",
                message = "La contraseña debe incluir mayúscula, minúscula, número y carácter especial")
        String password,

        @NotBlank(message = "El nombre completo es obligatorio")
        @Size(max = 150, message = "El nombre completo no puede superar 150 caracteres")
        String fullName) {

    // Recorta antes de validar @Email: sin esto, un correo con espacios al borde
    // falla el formato en lugar de detectarse como duplicado (MantisBT BUG-001).
    public RegisterCustomerRequest {
        email = email == null ? null : email.strip();
    }
}
